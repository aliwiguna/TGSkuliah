<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMahasiswaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbmahasiswa', function (Blueprint $table) {
            $table->increments('id');
            $table->string('nim');
            $table->string('namalengkap');
            $table->enum('gender', ['L', 'P']);
            $table->text('alamat');
            $table->integer('idjurusan');           
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbmahasiswa');
    }
}
