<form method="POST" action="{{url('barang/simpan')}}">
{{csrf_field()}}
kode barang <input type="text" name="kodebarang" ><br>
nama barang <input type="text" name="namabarang" ><br>
jumlah barang <input type="text" name="jumlahbarang" ><br>
<input type="submit" name="simpan" value="simpan">
</form>
       