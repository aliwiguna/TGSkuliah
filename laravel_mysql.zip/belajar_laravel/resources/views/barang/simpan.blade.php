kode barang : {{$kodebarang}}<br>
nama barang : {{$namabarbarang}}<br>
jmlh barang : {{$jumlahbarang}}<br>