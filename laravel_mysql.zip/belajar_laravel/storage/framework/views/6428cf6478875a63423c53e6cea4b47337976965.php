<form method="POST" action="<?php echo e(url('barang/simpan')); ?>">
<?php echo e(csrf_field()); ?>

kode barang <input type="text" name="kodebarang" ><br>
nama barang <input type="text" name="namabarang" ><br>
jumlah barang <input type="text" name="jumlahbarang" ><br>
<input type="submit" name="simpan" value="simpan">
</form>
       <?php /**PATH C:\Xampp\htdocs\belajar_laravel\resources\views/barang/form.blade.php ENDPATH**/ ?>