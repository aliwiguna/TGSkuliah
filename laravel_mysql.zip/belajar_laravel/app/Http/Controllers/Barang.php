<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Barang extends Controller
{
    
    function form(){
        return view('barang/form');
    }

    function simpan(Request $rq){
        $kode-$rq->kodebarang;
        $nama-$rq->namabarang;
        $jumlah-$rq->jumlahbarang;

        $data-array(
            'kodebarang' -> $kode,
            'namabarang' -> $nama,
            'jumlahbarang' -> $jumlah,
        );
        return view('barang/simpan',$data);
    }
}
